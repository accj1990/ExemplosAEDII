﻿namespace AEDII.Aulas.Revisao.Parte2.Ordenacao
{
    class Ordenador
    {
        public Ordenador()
        {

        }
    }
}
