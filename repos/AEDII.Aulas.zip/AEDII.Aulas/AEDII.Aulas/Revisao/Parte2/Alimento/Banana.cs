﻿namespace AEDII.Aulas.Revisao.Parte2.Alimento
{
    public class Banana : AlimentoEstoque
    {
        public Banana(int Id, string Nome, string Medida) : base(Id, Nome, Medida)
        {

        }
    }
}
