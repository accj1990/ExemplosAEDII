﻿namespace AEDII.Aulas.Revisao.Parte2.Alimento
{
    public class Ovos : AlimentoEstoque
    {
        public Ovos(int Id, string Nome, string Medida) : base(Id, Nome, Medida)
        {
        }
    }
}
