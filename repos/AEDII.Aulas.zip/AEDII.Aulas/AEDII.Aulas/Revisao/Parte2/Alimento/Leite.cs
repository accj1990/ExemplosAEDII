﻿namespace AEDII.Aulas.Revisao.Parte2.Alimento
{
    public class Leite : AlimentoEstoque
    {
        public Leite(int Id, string Nome, string Medida) : base(Id, Nome, Medida)
        {

        }

    }
}
