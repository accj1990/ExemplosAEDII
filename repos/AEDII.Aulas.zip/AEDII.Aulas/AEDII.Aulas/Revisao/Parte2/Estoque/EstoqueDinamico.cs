﻿namespace AEDII.Aulas.Revisao.Parte2.Estoque
{
    class EstoqueDinamico
    {
    }
}
