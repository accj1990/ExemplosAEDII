﻿namespace AEDII.Aulas
{
    public class ExecuteProgramParte2
    {
        public static void Execute()
        {
        }
    }
}
