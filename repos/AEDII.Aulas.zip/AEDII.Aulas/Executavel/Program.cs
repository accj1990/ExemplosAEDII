﻿using AEDII.Aulas;
using AEDII.Aulas.Revisao.Parte2.Alimento;
using AEDII.Aulas.Revisao.Parte2.Estoque;
public class Program
{
    private static void Main(string[] args)
    {
        //ExecuteProgramParte1.Execute();

        //ExecuteProgramParte2.Execute();

        EstoqueEstatico e1 = new EstoqueEstatico(35);
        int cont = 0;
        for (int i = 0; i < 10; i++)
        {
            Banana b = new Banana(i, "Banana", "kg");
            e1.Inserir(b);
            cont++;
        }

        for (int j = cont; j < 20; j++)
        {
            Leite l = new Leite(j, "Leite", "Litros");
            e1.Inserir(l);
            cont++;
        }

        for (int k = cont; k < 30; k++)
        {
            AlimentoEstoque ae = new AlimentoEstoque(k, "Macarrão", "Kg");
            e1.Inserir(ae);
            cont++;
        }

        for (int z = cont; z < 35; z++)
        {
            Ovos o = new Ovos(z, "Ovo", "Unidade");
            e1.Inserir(o);
            cont++;
        }

        e1.Exibir();

        B.Main();
    }
}